---
title: "Theca Cell"
type: "cell-type"
species: "Homo sapiens"
status: "expanded"
detail_level: "cell mechanism"
review_status: "educational synthesis; not independently peer reviewed"
updated: "2026-09-28"
tags: ["physiology", "v4", "cell-type"]
source_urls: ["https://openstax.org/books/anatomy-and-physiology-2e/pages/27-introduction"]
origin: "v4 educational expansion"
category_index: "[[Cell Types — MOC]]"
---

# Theca Cell

**Location / identity:** Ovarian follicular steroidogenic/supporting compartment.

**Function:** Supplies androgen precursors and structural/vascular support.

## Cellular machinery

LH-responsive steroidogenic cells express an enzyme complement that differs from granulosa cells. Precursor transfer enables cooperative estradiol production rather than requiring every cell to execute the entire pathway.

## Processes performed or supported

- [[Two-Cell Ovarian Steroidogenesis]]
- [[Steroid Hormone Synthesis]]
- [[Oogenesis and Folliculogenesis]]

Cell types contain additional subtypes and changing states. These are functional descriptions, not an exhaustive single-cell marker atlas.

## References and scope

- [OpenStax Anatomy and Physiology 2e: Reproductive system](https://openstax.org/books/anatomy-and-physiology-2e/pages/27-introduction)

Educational synthesis with pathway/chapter references; not independently peer reviewed. See [[Evidence and Scope]] for limits, species context and depth labels.


## Navigation

[[Cell Types — MOC]] · [[00 START HERE]]
