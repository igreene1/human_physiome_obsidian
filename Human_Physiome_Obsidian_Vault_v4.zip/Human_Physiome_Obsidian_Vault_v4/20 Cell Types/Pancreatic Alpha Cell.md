---
title: "Pancreatic Alpha Cell"
type: "cell-type"
tags: ["physiology", "cell-type"]
status: "filled"
detail_level: "reference summary"
review_status: "inherited v3 summary; not comprehensively reverified in v4"
origin: "uploaded v3; formatting and links maintained in v4"
category_index: "[[Cell Types — MOC]]"
---

# Pancreatic Alpha Cell

**Role:** Secretes glucagon, particularly when circulating glucose/insulin signalling is low and during fasting/exercise.

## Core mechanism

integrated glucose, amino-acid, paracrine and autonomic signals → Ca2+-dependent glucagon granule exocytosis → hepatic glucagon signalling

## Connected anatomy / physiology

- [[Pancreatic Islet]]
- [[Insulin and Glucagon]]
- [[Fasting Response]]
- [[Glycogen Metabolism]]
- [[Gluconeogenesis]]

## Questions to ask when expanding

- What membrane proteins create the cell's characteristic input/output?
- What intracellular signalling changes its behaviour?
- What substrate or ion gradients power the process?
- What whole-body variable changes when this cell increases or decreases activity?


## Navigation

[[Cell Types — MOC]] · [[00 START HERE]]
