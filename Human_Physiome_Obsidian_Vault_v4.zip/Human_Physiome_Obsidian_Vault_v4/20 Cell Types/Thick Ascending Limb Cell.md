---
title: "Thick Ascending Limb Cell"
type: "cell-type"
tags: ["physiology", "cell-type"]
status: "filled"
detail_level: "reference summary"
review_status: "inherited v3 summary; not comprehensively reverified in v4"
origin: "uploaded v3; formatting and links maintained in v4"
category_index: "[[Cell Types — MOC]]"
---

# Thick Ascending Limb Cell

**Role:** Reabsorbs NaCl without water and helps generate medullary hypertonicity.

## Core mechanism

[[NKCC2]] brings Na+/K+/2Cl− into cell → K+ recycling → Cl− exit + [[Na-K ATPase]] → dilute tubular fluid and build medullary gradient

## Connected anatomy / physiology

- [[Thick Ascending Limb]]
- [[NKCC2]]
- [[Urine Concentration and Dilution]]

## Questions to ask when expanding

- What membrane proteins create the cell's characteristic input/output?
- What intracellular signalling changes its behaviour?
- What substrate or ion gradients power the process?
- What whole-body variable changes when this cell increases or decreases activity?


## Navigation

[[Cell Types — MOC]] · [[00 START HERE]]
