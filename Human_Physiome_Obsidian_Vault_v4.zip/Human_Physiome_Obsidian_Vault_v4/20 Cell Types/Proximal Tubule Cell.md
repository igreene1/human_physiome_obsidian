---
title: "Proximal Tubule Cell"
type: "cell-type"
tags: ["physiology", "cell-type"]
status: "filled"
detail_level: "reference summary"
review_status: "inherited v3 summary; not comprehensively reverified in v4"
origin: "uploaded v3; formatting and links maintained in v4"
category_index: "[[Cell Types — MOC]]"
---

# Proximal Tubule Cell

**Role:** Bulk-reabsorbs filtered solutes and water and secretes selected organic compounds.

## Core mechanism

basolateral [[Na-K ATPase]] establishes Na+ gradient → apical cotransport/exchange including [[SGLT2]] → basolateral solute exit; water follows

## Connected anatomy / physiology

- [[Proximal Tubule]]
- [[SGLT2]]
- [[Na-K ATPase]]
- [[Acid-Base Homeostasis]]

## Questions to ask when expanding

- What membrane proteins create the cell's characteristic input/output?
- What intracellular signalling changes its behaviour?
- What substrate or ion gradients power the process?
- What whole-body variable changes when this cell increases or decreases activity?


## Navigation

[[Cell Types — MOC]] · [[00 START HERE]]
