---
title: "Platelet"
type: "cell-type"
species: "Homo sapiens"
status: "expanded"
detail_level: "cell mechanism"
review_status: "educational synthesis; not independently peer reviewed"
updated: "2026-09-28"
tags: ["physiology", "v4", "cell-type"]
source_urls: ["https://reactome.org/content/detail/R-HSA-109582"]
origin: "v4 educational expansion"
category_index: "[[Cell Types — MOC]]"
---

# Platelet

**Location / identity:** Circulating megakaryocyte-derived cell fragment.

**Function:** Integrates vascular injury signals and supports haemostatic surfaces.

## Cellular machinery

Granules, mitochondria, membrane receptors and a dynamic cytoskeleton support adhesion, secretion and aggregation. Absence of a nucleus does not mean absence of metabolism or all protein synthesis.

## Processes performed or supported

- [[Platelet Adhesion and Integrin Activation]]
- [[Platelet Activation]]
- [[Cell-Based Coagulation]]

Cell types contain additional subtypes and changing states. These are functional descriptions, not an exhaustive single-cell marker atlas.

## References and scope

- [Reactome: Hemostasis](https://reactome.org/content/detail/R-HSA-109582)

Educational synthesis with pathway/chapter references; not independently peer reviewed. See [[Evidence and Scope]] for limits, species context and depth labels.


## Navigation

[[Cell Types — MOC]] · [[00 START HERE]]
