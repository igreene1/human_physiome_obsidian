---
title: "Vascular Smooth Muscle Cell"
type: "cell-type"
tags: ["physiology", "cell-type"]
status: "filled"
detail_level: "reference summary"
review_status: "inherited v3 summary; not comprehensively reverified in v4"
origin: "uploaded v3; formatting and links maintained in v4"
category_index: "[[Cell Types — MOC]]"
---

# Vascular Smooth Muscle Cell

**Role:** Changes vessel diameter and therefore resistance, pressure and regional blood flow.

## Core mechanism

Ca2+-calmodulin → MLCK → myosin phosphorylation → contraction; cAMP/cGMP pathways generally favour relaxation through context-dependent mechanisms

## Connected anatomy / physiology

- [[Vascular Tone and Systemic Resistance]]
- [[Alpha1 Adrenergic Receptor]]
- [[Beta2 Adrenergic Receptor]]
- [[Nitric Oxide cGMP Signalling]]
- [[Arterial Blood Pressure Homeostasis]]

## Questions to ask when expanding

- What membrane proteins create the cell's characteristic input/output?
- What intracellular signalling changes its behaviour?
- What substrate or ion gradients power the process?
- What whole-body variable changes when this cell increases or decreases activity?


## Navigation

[[Cell Types — MOC]] · [[00 START HERE]]
