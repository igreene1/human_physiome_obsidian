---
title: "Schwann Cell"
type: "cell-type"
species: "Homo sapiens"
status: "expanded"
detail_level: "cell mechanism"
review_status: "educational synthesis; not independently peer reviewed"
updated: "2026-09-28"
tags: ["physiology", "v4", "cell-type"]
source_urls: ["https://reactome.org/content/detail/R-HSA-112316"]
origin: "v4 educational expansion"
category_index: "[[Cell Types — MOC]]"
---

# Schwann Cell

**Location / identity:** Peripheral nerves.

**Function:** Supports peripheral axons and forms myelin in the myelinating state.

## Cellular machinery

A myelinating Schwann cell forms one internodal segment; nonmyelinating states support other axon arrangements. Cell state changes during injury and repair, so a single myelin marker does not describe every Schwann cell.

## Processes performed or supported

- [[Myelination and Saltatory Conduction]]
- [[Action Potentials]]
- [[Wound Healing and Tissue Repair]]

Cell types contain additional subtypes and changing states. These are functional descriptions, not an exhaustive single-cell marker atlas.

## References and scope

- [Reactome: Neuronal system](https://reactome.org/content/detail/R-HSA-112316)

Educational synthesis with pathway/chapter references; not independently peer reviewed. See [[Evidence and Scope]] for limits, species context and depth labels.


## Navigation

[[Cell Types — MOC]] · [[00 START HERE]]
