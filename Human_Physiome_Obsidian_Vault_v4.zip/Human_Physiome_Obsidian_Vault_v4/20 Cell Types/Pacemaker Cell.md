---
title: "Pacemaker Cell"
type: "cell-type"
tags: ["physiology", "cell-type"]
status: "filled"
detail_level: "reference summary"
review_status: "inherited v3 summary; not comprehensively reverified in v4"
origin: "uploaded v3; formatting and links maintained in v4"
category_index: "[[Cell Types — MOC]]"
---

# Pacemaker Cell

**Role:** Generates spontaneous rhythmic depolarisation in the sinoatrial node.

## Core mechanism

HCN/funny current + Ca2+ currents gradually depolarise membrane → threshold → Ca2+-mediated upstroke → K+ repolarisation; autonomic signalling shifts slope/rate

## Connected anatomy / physiology

- [[Sinoatrial Node]]
- [[Autonomic Nervous System]]
- [[Beta1 Adrenergic Receptor]]
- [[cAMP PKA Signalling]]
- [[Heart Rate]]

## Questions to ask when expanding

- What membrane proteins create the cell's characteristic input/output?
- What intracellular signalling changes its behaviour?
- What substrate or ion gradients power the process?
- What whole-body variable changes when this cell increases or decreases activity?


## Navigation

[[Cell Types — MOC]] · [[00 START HERE]]
