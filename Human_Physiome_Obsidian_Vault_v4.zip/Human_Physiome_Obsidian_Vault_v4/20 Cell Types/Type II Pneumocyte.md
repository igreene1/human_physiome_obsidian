---
title: "Type II Pneumocyte"
type: "cell-type"
tags: ["physiology", "cell-type"]
status: "filled"
detail_level: "reference summary"
review_status: "inherited v3 summary; not comprehensively reverified in v4"
origin: "uploaded v3; formatting and links maintained in v4"
category_index: "[[Cell Types — MOC]]"
---

# Type II Pneumocyte

**Role:** Produces pulmonary surfactant and can proliferate/differentiate during alveolar epithelial repair.

## Core mechanism

surfactant phospholipid/protein secretion → reduced alveolar surface tension → improved stability/compliance

## Connected anatomy / physiology

- [[Alveolus]]
- [[Pulmonary Ventilation]]
- [[Tissue Injury Response]]

## Questions to ask when expanding

- What membrane proteins create the cell's characteristic input/output?
- What intracellular signalling changes its behaviour?
- What substrate or ion gradients power the process?
- What whole-body variable changes when this cell increases or decreases activity?


## Navigation

[[Cell Types — MOC]] · [[00 START HERE]]
