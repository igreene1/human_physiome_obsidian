---
title: "Type I Pneumocyte"
type: "cell-type"
tags: ["physiology", "cell-type"]
status: "filled"
detail_level: "reference summary"
review_status: "inherited v3 summary; not comprehensively reverified in v4"
origin: "uploaded v3; formatting and links maintained in v4"
category_index: "[[Cell Types — MOC]]"
---

# Type I Pneumocyte

**Role:** Thin squamous alveolar epithelial cell specialised for gas diffusion.

## Core mechanism

forms most alveolar gas-exchange surface; minimal diffusion distance supports O2/CO2 exchange with adjacent capillary

## Connected anatomy / physiology

- [[Alveolus]]
- [[Alveolar Gas Exchange]]
- [[PaO2]]
- [[PaCO2]]

## Questions to ask when expanding

- What membrane proteins create the cell's characteristic input/output?
- What intracellular signalling changes its behaviour?
- What substrate or ion gradients power the process?
- What whole-body variable changes when this cell increases or decreases activity?


## Navigation

[[Cell Types — MOC]] · [[00 START HERE]]
