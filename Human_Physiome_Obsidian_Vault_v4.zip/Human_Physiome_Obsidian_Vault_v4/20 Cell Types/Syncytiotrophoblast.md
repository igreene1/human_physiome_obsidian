---
title: "Syncytiotrophoblast"
type: "cell-type"
species: "Homo sapiens"
status: "expanded"
detail_level: "cell mechanism"
review_status: "educational synthesis; not independently peer reviewed"
updated: "2026-09-28"
tags: ["physiology", "v4", "cell-type"]
source_urls: ["https://openstax.org/books/anatomy-and-physiology-2e/pages/28-introduction"]
origin: "v4 educational expansion"
category_index: "[[Cell Types — MOC]]"
---

# Syncytiotrophoblast

**Location / identity:** Multinucleated outer villous trophoblast layer.

**Function:** Supports placental exchange and endocrine functions.

## Cellular machinery

Fusion of trophoblast precursors maintains an extensive interface with maternal blood in the intervillous space. Transport and hormone production are selective/metabolically active; maternal and fetal blood are normally separated.

## Processes performed or supported

- [[Placental Transport]]
- [[Placental Endocrine Function]]
- [[Trophoblast Differentiation and Spiral Artery Remodelling]]

Cell types contain additional subtypes and changing states. These are functional descriptions, not an exhaustive single-cell marker atlas.

## References and scope

- [OpenStax Anatomy and Physiology 2e: Development and inheritance](https://openstax.org/books/anatomy-and-physiology-2e/pages/28-introduction)

Educational synthesis with pathway/chapter references; not independently peer reviewed. See [[Evidence and Scope]] for limits, species context and depth labels.


## Navigation

[[Cell Types — MOC]] · [[00 START HERE]]
