---
title: "Thyroid Follicular Cell"
type: "cell-type"
tags: ["physiology", "cell-type"]
status: "filled"
detail_level: "reference summary"
review_status: "inherited v3 summary; not comprehensively reverified in v4"
origin: "uploaded v3; formatting and links maintained in v4"
category_index: "[[Cell Types — MOC]]"
---

# Thyroid Follicular Cell

**Role:** Synthesises, stores and releases thyroid hormone.

## Core mechanism

TSH → [[TSH Receptor]] → cAMP/PKA → [[Sodium Iodide Symporter]] uptake → iodination/coupling on thyroglobulin → colloid storage → T4/T3 release

## Connected anatomy / physiology

- [[Thyroid Gland]]
- [[Thyroid Hormone Physiology]]
- [[TSH Receptor]]
- [[Sodium Iodide Symporter]]
- [[TSH and Free T4]]

## Questions to ask when expanding

- What membrane proteins create the cell's characteristic input/output?
- What intracellular signalling changes its behaviour?
- What substrate or ion gradients power the process?
- What whole-body variable changes when this cell increases or decreases activity?


## Navigation

[[Cell Types — MOC]] · [[00 START HERE]]
