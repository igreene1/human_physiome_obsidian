---
title: "T Lymphocyte"
type: "cell-type"
species: "Homo sapiens"
status: "expanded"
detail_level: "cell mechanism"
review_status: "educational synthesis; not independently peer reviewed"
updated: "2026-09-28"
tags: ["physiology", "v4", "cell-type"]
source_urls: ["https://reactome.org/content/detail/R-HSA-168256"]
origin: "v4 educational expansion"
category_index: "[[Cell Types — MOC]]"
---

# T Lymphocyte

**Location / identity:** Thymus-derived adaptive lymphocyte populations.

**Function:** Uses TCR recognition to coordinate helper, regulatory or cytotoxic functions.

## Cellular machinery

CD3-associated signalling, costimulation and cytokine inputs determine activation. CD4/CD8 are useful subsets but do not by themselves specify every functional state or antigen restriction pattern.

## Processes performed or supported

- [[TCR Signalling and Costimulation]]
- [[T Cell Differentiation]]
- [[CD8 Cytotoxic Killing]]

Cell types contain additional subtypes and changing states. These are functional descriptions, not an exhaustive single-cell marker atlas.

## References and scope

- [Reactome: Immune system](https://reactome.org/content/detail/R-HSA-168256)

Educational synthesis with pathway/chapter references; not independently peer reviewed. See [[Evidence and Scope]] for limits, species context and depth labels.


## Navigation

[[Cell Types — MOC]] · [[00 START HERE]]
