---
title: "Sertoli Cell"
type: "cell-type"
species: "Homo sapiens"
status: "expanded"
detail_level: "cell mechanism"
review_status: "educational synthesis; not independently peer reviewed"
updated: "2026-09-28"
tags: ["physiology", "v4", "cell-type"]
source_urls: ["https://openstax.org/books/anatomy-and-physiology-2e/pages/27-introduction"]
origin: "v4 educational expansion"
category_index: "[[Cell Types — MOC]]"
---

# Sertoli Cell

**Location / identity:** Seminiferous-tubule supporting cell.

**Function:** Creates the germ-cell niche and blood-testis barrier.

## Cellular machinery

FSH/androgen-responsive functions include metabolic support, junctional remodelling, phagocytosis and inhibin production. It supports spermatogenesis but does not itself become a sperm.

## Processes performed or supported

- [[Sertoli Cell Support and Blood-Testis Barrier]]
- [[Spermatogenesis]]
- [[Reproductive Endocrine Axes]]

Cell types contain additional subtypes and changing states. These are functional descriptions, not an exhaustive single-cell marker atlas.

## References and scope

- [OpenStax Anatomy and Physiology 2e: Reproductive system](https://openstax.org/books/anatomy-and-physiology-2e/pages/27-introduction)

Educational synthesis with pathway/chapter references; not independently peer reviewed. See [[Evidence and Scope]] for limits, species context and depth labels.


## Navigation

[[Cell Types — MOC]] · [[00 START HERE]]
