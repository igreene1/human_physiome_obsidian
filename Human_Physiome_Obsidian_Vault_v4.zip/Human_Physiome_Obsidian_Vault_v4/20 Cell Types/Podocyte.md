---
title: "Podocyte"
type: "cell-type"
tags: ["physiology", "cell-type"]
status: "filled"
detail_level: "reference summary"
review_status: "inherited v3 summary; not comprehensively reverified in v4"
origin: "uploaded v3; formatting and links maintained in v4"
category_index: "[[Cell Types — MOC]]"
---

# Podocyte

**Role:** Specialised glomerular epithelial cell forming the outer filtration barrier and slit diaphragms.

## Core mechanism

interdigitating foot processes + slit diaphragm proteins maintain selective filtration and glomerular capillary architecture

## Connected anatomy / physiology

- [[Glomerulus]]
- [[Renal Blood Flow and GFR]]
- [[Creatinine and eGFR]]

## Questions to ask when expanding

- What membrane proteins create the cell's characteristic input/output?
- What intracellular signalling changes its behaviour?
- What substrate or ion gradients power the process?
- What whole-body variable changes when this cell increases or decreases activity?


## Navigation

[[Cell Types — MOC]] · [[00 START HERE]]
