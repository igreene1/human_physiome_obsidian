---
title: "Skeletal Myocyte"
type: "cell-type"
tags: ["physiology", "cell-type"]
status: "filled"
detail_level: "reference summary"
review_status: "inherited v3 summary; not comprehensively reverified in v4"
origin: "uploaded v3; formatting and links maintained in v4"
category_index: "[[Cell Types — MOC]]"
---

# Skeletal Myocyte

**Role:** Generates force and is a major insulin- and exercise-responsive glucose sink.

## Core mechanism

motor AP → sarcolemmal/T-tubule AP → SR Ca2+ release → troponin activation → cross-bridge cycling; ATP supplied by phosphagen, glycolytic and oxidative pathways

## Connected anatomy / physiology

- [[Skeletal Muscle]]
- [[Skeletal Muscle Excitation-Contraction Coupling]]
- [[Cross-Bridge Cycling]]
- [[GLUT4]]
- [[Muscle Energy Systems]]

## Questions to ask when expanding

- What membrane proteins create the cell's characteristic input/output?
- What intracellular signalling changes its behaviour?
- What substrate or ion gradients power the process?
- What whole-body variable changes when this cell increases or decreases activity?


## Navigation

[[Cell Types — MOC]] · [[00 START HERE]]
