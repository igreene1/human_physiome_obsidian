---
title: "Pancreatic Duct Cell"
type: "cell-type"
species: "Homo sapiens"
status: "expanded"
detail_level: "cell mechanism"
review_status: "educational synthesis; not independently peer reviewed"
updated: "2026-09-28"
tags: ["physiology", "v4", "cell-type"]
source_urls: ["https://openstax.org/books/anatomy-and-physiology-2e/pages/23-introduction"]
origin: "v4 educational expansion"
category_index: "[[Cell Types — MOC]]"
---

# Pancreatic Duct Cell

**Location / identity:** Polarised pancreatic duct epithelium.

**Function:** Adds bicarbonate-rich fluid to pancreatic secretion.

## Cellular machinery

Secretin-cAMP signalling recruits apical CFTR/exchanger-related anion transport with basolateral substrate support. Electrolyte and water flow helps neutralise acid and deliver enzymes.

## Processes performed or supported

- [[Pancreatic Duct Bicarbonate Secretion]]
- [[cAMP PKA Signalling]]
- [[Membrane Transport]]

Cell types contain additional subtypes and changing states. These are functional descriptions, not an exhaustive single-cell marker atlas.

## References and scope

- [OpenStax Anatomy and Physiology 2e: Digestive system](https://openstax.org/books/anatomy-and-physiology-2e/pages/23-introduction)

Educational synthesis with pathway/chapter references; not independently peer reviewed. See [[Evidence and Scope]] for limits, species context and depth labels.


## Navigation

[[Cell Types — MOC]] · [[00 START HERE]]
